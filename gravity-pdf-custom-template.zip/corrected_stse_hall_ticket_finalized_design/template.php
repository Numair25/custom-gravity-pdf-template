<?php
/*
 * Template Name: Professional Hall Ticket Template
 * Description: A Gravity PDF template with a professional and neutral layout.
 */

/* Prevent direct access */
if ( ! class_exists( 'GFForms' ) ) {
    return;
}
?>

<!-- Inline styles -->
<style>
    body {
        font-family: Arial, sans-serif;
        font-size: 12px;
        margin: 0;
        padding: 0;
    }
    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 20px;
        border-bottom: 2px solid #EE1C2A;
        margin-bottom: 20px;
    }
    .logo {
        width: 200px;
        height: auto;
    }
    .header-title {
        text-align: center;
        flex: 1;
        margin-top: -60px;
    }
    .header-title h1 {
        font-size: 22px;
        margin: 0;
        color: #EE1C2A;
    }
    .header-title h2 {
        font-size: 18px;
        margin: 5px 0;
        color: #333;
    }
    .header-title p {
        font-size: 14px;
        margin: 5px 0;
    }
    .photo-box {
        width: 200px;
        height: 150px;
        border: 1px solid #000;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 10px;
        margin-top: -115px;
        margin-left: 850px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
        margin-bottom: 20px;
        border: none;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 12px 15px;
        text-align: left;
    }
    th {
        background-color: #f4f4f4;
        color: #333;
        text-align: center;
        font-weight: bold;
    }
    .section-title {
        background-color: #f9f9f9;
        color: #000;
        font-size: 16px;
        text-align: left;
        padding: 10px;
        margin-bottom: 15px;
        border-left: 4px solid #EE1C2A;
    }
    .info-box {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
        padding: 15px;
        background-color: #f9f9f9;
        border: 1px solid #ddd;
    }
    .info-box div {
        width: 48%;
    }
</style>

<div class="header">
    <!-- Logo -->
    <div>
        <img src="https://numair.amlc.in/wp-content/uploads/2024/12/Standard-Touch-Logo-1-1.png" alt="Standard Touch" class="logo">
    </div>

    <!-- Title Section -->
    <div class="header-title">
        <h1>Professional Entry Pass</h1>
        <h2>(2025-26)</h2>
    </div>

    <!-- Candidate Photo -->
    <div class="photo-box">Photo</div>
</div>

<div class="section-title">Personal Information</div>
<div class="info-box">
    <div>
        <p><strong>Name:</strong> John Doe</p>
        <p><strong>Gender:</strong> Male</p>
        <p><strong>Country:</strong> India</p>
    </div>
    <div>
        <p><strong>State:</strong> Karnataka</p>
        <p><strong>Contact Number:</strong> +91-1234567890</p>
    </div>
</div>

<div class="section-title">Event Details</div>
<table>
    <thead>
        <tr>
            <th>Pass ID</th>
            <th>Event Name</th>
            <th>Venue</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>ST12345</td>
            <td>Professional Meet</td>
            <td>123 Main Street, Bengaluru</td>
        </tr>
    </tbody>
</table>

<div class="section-title">Additional Information</div>
<div class="info-box">
    <div>
        <p><strong>Date of Birth:</strong> 01/01/2000</p>
    </div>
    <div>
        <p><strong>Designation:</strong> Manager</p>
        <p><strong>ID Number:</strong> 1234-5678-9012</p>
    </div>
</div>

<div class="section-title">Event Schedule</div>
<table>
    <thead>
        <tr>
            <th>Date</th>
            <th>Time</th>
            <th>Duration</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>22nd December 2024</td>
            <td>11:00 AM to 2:00 PM</td>
            <td>3 Hours</td>
        </tr>
    </tbody>
</table>

<div style="display: flex; justify-content: space-between; margin-top: 30px;">
    <div style="text-align: center;">
        <hr style="border: 1px solid #000; width: 80%;">
        <p>Participant Signature</p>
    </div>
    <div style="text-align: center;">
        <hr style="border: 1px solid #000; width: 80%;">
        <p>Authorized Signatory</p>
    </div>
</div>
